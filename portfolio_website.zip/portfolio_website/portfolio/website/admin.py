from django.contrib import admin
from .models import Image,Education,WorkExperience

#Registering the database models to the admin interface
admin.site.register(Image)
admin.site.register(Education)
admin.site.register(WorkExperience)


