from django.shortcuts import render
from django.http import  HttpResponse, JsonResponse
from .models import Education,Image,WorkExperience

# Fetching Education field data from database
education=Education.objects.all()
ed_Uclan=Education.objects.filter(UniversityName='University of Central Lancashire').first()
ed_lpu=Education.objects.filter(UniversityName='Lovely Professional University').first()
content_Uclan=ed_Uclan.content.split(';')
content_lpu=ed_lpu.content.split(';')
lpu_array=[ed_lpu,content_lpu]
uclan_array=[ed_Uclan,content_Uclan]

#Fetching work experience from database
dataanalyst_experience=WorkExperience.objects.filter(CompanyName='Data Analyst at Aveit Solutions Pvt Ltd').first()
freelance_experience=WorkExperience.objects.filter(CompanyName='Freelance Web Developer at KrishChem Fertilisers').first()
content_dataanalyst=dataanalyst_experience.JobResponsibilities.split(';')
content_freelance=freelance_experience.JobResponsibilities.split(';')
print(content_freelance)
dataanalyst_array=[dataanalyst_experience,content_dataanalyst]
freelance_array=[freelance_experience,content_freelance]
def home(request):
    context={
        'education':[uclan_array,lpu_array],
        'work_experience':[dataanalyst_array,freelance_array]
    }
    return render(request,'website/home.html',context)

def about(request):
    return HttpResponse('<h1> This is about page </h1>')